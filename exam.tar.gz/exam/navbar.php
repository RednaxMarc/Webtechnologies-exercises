<!DOCTYPE html>
<html lang="en">
<head>
	<title></title>
	<style type="text/css" media="screen">
		body {
		background: #eeeeee; }
		
		.navbar {
		text-align:center;
		font-family: sans-serif;
		padding: 2em;}
		.navbar span {
		margin: 2em 2.5em;}
		
		.contentbox {
		width: 98%;
		margin: 0 10px;
		border: grey 1px solid;
		font-family: sans-serif;
		}
		.header {
		width: 100%;
		box-sizing: border-box;
		background: grey;
		color: white;
		font-family: sans-serif;
		font-size: 30px;
		font-weight: bold;
		text-align: center;
		padding: 0.5em;}
		.content {
		background: white;
		font-family: sans-serif;
		}
		.navbar a:hover {
		background: rgb(250,250,250);
		padding: 0.7em;}
	</style>
</head>
<body>
<div class="navbar">
<span><a href="index.php">Home</a></span>
<span><a href="submit.php">Submit multiFasta</a></span>
<span><a href="visualise.php">Visualise</a></span>
</div>
</body>
</html>

